import os, subprocess, tempfile, shutil
from pathlib import Path
import sys
binary = Path(sys.argv[1] if len(sys.argv) > 1 else 'dist/pt').resolve()
Path('verification').mkdir(exist_ok=True)
with tempfile.TemporaryDirectory(dir='verification') as tmp:
    root = Path(tmp).resolve()
    app = root/'app'
    app.mkdir()
    shutil.copy2(binary, app/'pt')
    binary = app/'pt'
    project = root/'project'
    project.mkdir()
    (project/'.git').mkdir()
    (project/'.gitignore').write_text('*.log\nnested/private.txt\n')
    (project/'.ppignore').write_text('skip.txt\n')
    (project/'hello.txt').write_text('Zażółć gęślą jaźń\n')
    (project/'debug.log').write_text('ignored')
    (project/'skip.txt').write_text('ignored')
    (project/'nested').mkdir()
    (project/'nested/private.txt').write_text('ignored')
    (project/'nested/keep.txt').write_text('retained\n')
    (project/'binary.bin').write_bytes(b'\x00\x01')
    env = {'PATH':'', 'TMPDIR':str(root), 'HOME':str(root), 'LANG':'C.UTF-8'}
    def run(*args, ok=True):
        result = subprocess.run([str(binary), *map(str,args)],cwd=root,env=env,text=True,capture_output=True)
        assert (result.returncode == 0) == ok, (args,result.stdout,result.stderr)
        return result
    run('--help')
    run('context',project)
    context = next((app/'data/contexts/project').glob('*.yaml'))
    content = context.read_text()
    assert 'hello.txt' in content and 'Zażółć' in content and 'nested/keep.txt' in content
    assert 'debug.log' not in content and 'skip.txt' not in content and 'private.txt' not in content
    run('tree',project)
    tree = next((app/'data/trees/project').glob('*.yaml')).read_text()
    assert 'hello.txt (1)' in tree and 'debug.log' not in tree
    assert not (root/'data').exists()
    target = root/'target'
    target.mkdir()
    run('apply',target,context,'--dry-run')
    assert not list(target.iterdir())
    run('apply',target,context)
    assert (target/'hello.txt').read_text() == 'Zażółć gęślą jaźń\n'
    assert not (target/'binary.bin').exists()
    (target/'hello.txt').write_text('keep me')
    run('apply',target,context,'--no-clobber')
    assert (target/'hello.txt').read_text() == 'keep me'
    bad=root/'bad.yaml'
    bad.write_text('files:\n  - path: "../escape.txt"\n    content: |-\n      bad\n')
    run('apply',target,bad,ok=False)
    assert not (root/'escape.txt').exists()
    run('context',root/'missing',ok=False)
    print('PASS: standalone help, context, tree, apply, ignore rules, Unicode, placeholders, dry-run, no-clobber, traversal rejection; PATH empty.')
