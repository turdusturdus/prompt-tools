#!/bin/sh
set -eu
cd "$(dirname "$0")"
# Wymagania TYLKO na komputerze budującym: Python 3.12 z venv oraz ripgrep.
# Buduj na Ubuntu 24.04 x86-64 dla tego samego celu co dostarczony plik.
command -v rg >/dev/null
python3 -m venv .build-venv
.build-venv/bin/python -m pip install 'pyinstaller==6.22.2' 'pyinstaller-hooks-contrib==2026.7'
.build-venv/bin/python -m PyInstaller --noconfirm --clean --onefile \
  --name pt --paths src --add-binary "$(command -v rg):bin" standalone.py
