PROMPT-TOOLS — wersja samodzielna dla Ubuntu 24.04, x86-64 (Intel/AMD)

Uruchomienie po rozpakowaniu:
  ./pt --help
  ./pt context /sciezka/do/projektu
  ./pt tree /sciezka/do/projektu
  ./pt apply /sciezka/docelowa pliki.yaml --dry-run
  ./pt apply /sciezka/docelowa pliki.yaml

Plik pt zawiera Python 3.12.14 i ripgrep. Nie wymaga pip, pipx, venv,
systemowego Pythona, instalacji Gita ani ripgrepa. Korzysta ze standardowych
bibliotek Ubuntu, w tym glibc. To aplikacja terminalowa, bez okna GUI.
Nie jest przeznaczona dla ARM64 ani dla Windows.

Można skopiować sam plik pt w dowolne miejsce. W razie utraty praw:
  chmod +x pt
Wyniki powstają w katalogu aplikacji, OBOK pliku wykonywalnego pt,
niezależnie od bieżącego katalogu terminala. Katalog aplikacji musi być zapisywalny:
  data/contexts/<projekt>/<projekt>_YYYYMMDD_HHMM.yaml
  data/trees/<projekt>/<projekt>_YYYYMMDD_HHMM.yaml

Program przy każdym starcie rozpakowuje komponenty do katalogu tymczasowego
i usuwa je po zakończeniu. Katalog musi zezwalać na zapis i wykonywanie kodu.
Standardowy /tmp w Ubuntu jest wystarczający. Przy niestandardowej konfiguracji
można wskazać własny katalog przez TMPDIR.

Selekcja plików zachowuje logikę oryginału: jeśli jest dostępny Git i katalog
jest repozytorium, używa git ls-files. W przeciwnym razie używa dołączonego
ripgrepa. Obsługa .gitignore przez rg podlega jego regułom (domyślnie wymaga
repozytorium). .ppignore działa tak jak w projekcie wejściowym.
Git jest opcjonalny; bez niego lista może się różnić dla śledzonych plików
pasujących do .gitignore. Parser YAML pozostaje ograniczonym parserem oryginału.

Weryfikacja:
- 15 oryginalnych testów: zaliczone.
- Gotowy plik: help, context, tree, apply przy pustym PATH i bez PYTHONPATH.
- Sprawdzone: .gitignore, .ppignore, zagnieżdżone pliki, polskie znaki,
  pomijanie binariów, --dry-run, --no-clobber, odrzucanie ścieżki ../.
- Testy wykonano w środowisku Linux x86-64 z glibc 2.39; nie uruchamiano
  osobnej maszyny wirtualnej ze świeżo zainstalowanym Ubuntu.
- Starsze Ubuntu i inne architektury wymagają osobnej kompilacji i testów.

Zmiany względem ZIP-a wejściowego:
- Dołączony interpreter i ripgrep w pojedynczym pliku ELF (PyInstaller).
- W wersji spakowanej ripgrep jest znajdowany wewnątrz paczki.
- W wersji spakowanej wyniki są zapisywane obok pliku wykonywalnego pt.
- Dołączone źródła i skrypt ponownej kompilacji (source/build-ubuntu.sh).
Wymagania narzędzi kompilacji nie dotyczą użytkownika gotowego pliku pt.

Licencje dołączonych komponentów znajdują się w licenses/.
